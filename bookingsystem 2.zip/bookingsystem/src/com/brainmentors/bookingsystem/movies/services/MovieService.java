package com.brainmentors.bookingsystem.movies.services;

import com.brainmentors.bookingsystem.movies.dto.MovieDTO;
import com.brainmentors.bookingsystem.movies.repository.MovieRepository;

public class MovieService {
	
	public MovieDTO getMovieByName(String movieName) {
		MovieRepository movieRepo = new MovieRepository();
		for(MovieDTO movieObject  : movieRepo.getAllMovies()) {
			if(movieObject!=null) {
				if(movieObject.getName().equalsIgnoreCase(movieName)) {
					return movieObject;
				}
			}
		}
		return null;
	}

}
