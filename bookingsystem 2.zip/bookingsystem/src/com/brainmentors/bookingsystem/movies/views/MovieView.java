package com.brainmentors.bookingsystem.movies.views;

import java.util.Scanner;

import com.brainmentors.bookingsystem.movies.dto.MovieDTO;
import com.brainmentors.bookingsystem.movies.services.MovieService;

public class MovieView {
	
	public void showMovie(){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Movie Name");
		String movieName= scanner.next();
		MovieService movieService = new MovieService();
		MovieDTO movieDTO = movieService.getMovieByName(movieName);
		if(movieDTO == null) {
			System.out.println("No Movie Exist....");
		}
		else {
			System.out.println("Movie "+movieDTO);
		}
		//scanner.close();
	}

}
