package com.brainmentors.bookingsystem.movies.dto;

public class AudiDTO {
	private int capacity;
	private TicketDTO[] tickets;
	public AudiDTO() {
		capacity = 5;
		tickets = new TicketDTO[capacity];
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public TicketDTO[] getTickets() {
		return tickets;
	}
	public void setTickets(TicketDTO[] tickets) {
		this.tickets = tickets;
	}
	

}
