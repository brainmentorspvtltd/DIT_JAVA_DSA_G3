package com.brainmentors.bookingsystem.movies.repository;

import com.brainmentors.bookingsystem.movies.dto.AudiDTO;
import com.brainmentors.bookingsystem.movies.dto.ShowDTO;
import com.brainmentors.bookingsystem.movies.dto.TicketDTO;

public class TicketRepository {
	public TicketDTO[] addTickets(AudiDTO audiDTO) {
		TicketDTO tickets[] = audiDTO.getTickets();
		return tickets;
	}
}
