package com.brainmentors.bookingsystem.movies.repository;

import com.brainmentors.bookingsystem.movies.dto.AudiDTO;
import com.brainmentors.bookingsystem.movies.dto.MovieDTO;
import com.brainmentors.bookingsystem.movies.dto.ShowDTO;

public class AudiRepository {
	private TicketRepository ticketRepo;
	public AudiDTO addAudi(ShowDTO showDTO) {
		AudiDTO audi = new AudiDTO();
		 
		
		audi.setCapacity(10);
		audi.setTickets(ticketRepo.addTickets(audi));
		return audi;
	}
}
