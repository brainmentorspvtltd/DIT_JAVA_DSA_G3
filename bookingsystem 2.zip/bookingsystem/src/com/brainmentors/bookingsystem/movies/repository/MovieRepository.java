package com.brainmentors.bookingsystem.movies.repository;

import com.brainmentors.bookingsystem.movies.dto.MovieDTO;

public class MovieRepository {
	private ShowRepository showRepo;
	public MovieDTO[] getAllMovies() {
		MovieDTO[] movies = new MovieDTO[2];
		MovieDTO movie = new MovieDTO();
		movie.setName("Pushpa");
		movie.setPrice(200);
		movie.setDesc("In Hindi");
		movie.setRating(8.5);
		showRepo.addShow(movie);
		movies[0] =movie;
		//movies[1] = new MovieDTO("KGF", 100, "In Hindi", 8.6);
		return movies;
	}
	

}
