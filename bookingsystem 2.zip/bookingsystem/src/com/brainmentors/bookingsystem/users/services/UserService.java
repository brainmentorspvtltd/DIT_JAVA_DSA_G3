package com.brainmentors.bookingsystem.users.services;

import com.brainmentors.bookingsystem.users.dto.UserDTO;
import com.brainmentors.bookingsystem.users.repository.UserRepository;

public class UserService {
	
	// Contains the logic for Authentication
	public UserDTO auth(UserDTO user) {
		UserRepository userRepository = new UserRepository();
		UserDTO users[] =userRepository.getAllUsers();
		for(UserDTO userObject: users) {
			if(userObject!=null) {
				if(userObject.getEmail().equals(user.getEmail()) 
						&& userObject.getPassword().equals(user.getPassword())) {
					return userObject;
				}
			}
		}
		return null;
	}

}
