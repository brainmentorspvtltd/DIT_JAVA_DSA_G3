package com.brainmentors.bookingsystem.users.views; // 1st line

import java.util.Scanner;

import com.brainmentors.bookingsystem.movies.views.MovieView;
import com.brainmentors.bookingsystem.users.dto.UserDTO;
import com.brainmentors.bookingsystem.users.services.UserService;

// Login Screen / Console IO
public class LoginView {
	public static void main(String[] args) {
		LoginView loginView = new LoginView();
		loginView.input();
	}
	public void input() {
		Scanner scanner = new Scanner(System.in);
		// Taking User Input 
		System.out.println("Enter the Email");
		String email = scanner.next();
		System.out.println("Enter the Password");
		String password = scanner.next();
		// Store Input to the DTO
		UserDTO userDTO = new UserDTO();
		userDTO.setEmail(email);
		userDTO.setPassword(password);
		// Calling a Service
		UserService userService = new UserService();
		UserDTO userObject = userService.auth(userDTO);
		if(userObject==null) {
			System.out.println("Invalid Userid or Password");
			
		}
		else {
			System.out.println("Welcome "+userObject.getName());
			
			MovieView movieView = new MovieView();
			while(true) {
			movieView.showMovie();
			System.out.println("Press q for Exit");
			String choice = scanner.next();
			if(choice.equalsIgnoreCase("q")) {
				System.exit(0);
				//return ;
			}
			}
		}
		scanner.close();
		
		
		// Take Input for Userid and Password
	}

}
