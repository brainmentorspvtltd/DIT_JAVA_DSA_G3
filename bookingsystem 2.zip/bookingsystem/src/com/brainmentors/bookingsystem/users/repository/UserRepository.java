package com.brainmentors.bookingsystem.users.repository;

import com.brainmentors.bookingsystem.users.dto.UserDTO;
/*
 * In Memory Data 
 */
public class UserRepository {
	
	public UserDTO[] getAllUsers(){
		int index = 0;
		UserDTO users[] = new UserDTO[5]; // Array of Object
		// Get 5 Users from the Memory
		UserDTO userDTO = new UserDTO("amit@yahoo.com","a123");
		userDTO.setName("Amit");
		userDTO.setPhone("2222");
		users[index] = userDTO;
		index++;
 		userDTO = new UserDTO("ram@yahoo.com","a123");
		userDTO.setName("Ram");
		userDTO.setPhone("3333");
		users[index] = userDTO;
		index++;
		
		return users;
	}

}
