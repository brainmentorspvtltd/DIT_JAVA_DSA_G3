package com.skillrisers.chatapp.users.repository;

public class UserRepository {
	// DB User CRUD

}
