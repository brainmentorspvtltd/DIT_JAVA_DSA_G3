package com.skillrisers.chatapp.users.views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.border.LineBorder;

import com.skillrisers.chatapp.utils.DBConnection;

import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UserView {

	private JFrame userViewFrame;
	private JTextField useridtxt;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					UserView window = new UserView();
					window.userViewFrame.setVisible(true);
					try {
						DBConnection.getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
	}

	/**
	 * Create the application.
	 */
	public UserView() {
		initialize();
	}
	
	
	private void doRegister() {
		String userid = useridtxt.getText();
		char password[] = passwordField.getPassword();
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		userViewFrame = new JFrame();
		userViewFrame.setTitle("Login/Register Form");
		userViewFrame.setResizable(false);
		userViewFrame.getContentPane().setBackground(Color.WHITE);
		userViewFrame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Register/Login");
		lblNewLabel.setForeground(Color.MAGENTA);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel.setBounds(192, 18, 169, 25);
		userViewFrame.getContentPane().add(lblNewLabel);
		
		JLabel useridlbl = new JLabel("userid");
		useridlbl.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		useridlbl.setHorizontalAlignment(SwingConstants.RIGHT);
		useridlbl.setBounds(64, 95, 81, 20);
		userViewFrame.getContentPane().add(useridlbl);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPassword.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblPassword.setBounds(64, 146, 81, 20);
		userViewFrame.getContentPane().add(lblPassword);
		
		useridtxt = new JTextField();
		useridtxt.setBorder(new LineBorder(Color.BLACK, 3, true));
		useridtxt.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		useridtxt.setBounds(192, 89, 262, 30);
		userViewFrame.getContentPane().add(useridtxt);
		useridtxt.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		passwordField.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		passwordField.setBounds(192, 144, 262, 35);
		userViewFrame.getContentPane().add(passwordField);
		
		JButton loginBt = new JButton("Login");
		loginBt.setBorder(new LineBorder(new Color(0, 0, 0)));
		loginBt.setIcon(new ImageIcon(UserView.class.getResource("/assets/2170153.png")));
		loginBt.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		loginBt.setBounds(51, 191, 231, 130);
		userViewFrame.getContentPane().add(loginBt);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnRegister.setBorder(new LineBorder(new Color(0, 0, 0)));
		btnRegister.setIcon(new ImageIcon(UserView.class.getResource("/assets/user-png-icon-8.jpeg")));
		btnRegister.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		btnRegister.setBounds(294, 191, 355, 130);
		userViewFrame.getContentPane().add(btnRegister);
		
		JLabel iconlbl = new JLabel("");
		iconlbl.setIcon(new ImageIcon(UserView.class.getResource("/assets/user.png")));
		iconlbl.setBounds(452, 18, 225, 272);
		userViewFrame.getContentPane().add(iconlbl);
		//userViewFrame.setBackground(Color.WHITE);
		userViewFrame.setBounds(100, 100, 683, 353);
		userViewFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		userViewFrame.setLocationRelativeTo(null);
	}
}
