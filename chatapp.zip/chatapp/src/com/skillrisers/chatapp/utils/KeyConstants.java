package com.skillrisers.chatapp.utils;

public interface KeyConstants {
	
	String DB_URL = "DB_URL";
	String DB_USERID = "userid";
	String DB_PWD = "password";
	String DRIVER_NAME = "driver_name";

}
