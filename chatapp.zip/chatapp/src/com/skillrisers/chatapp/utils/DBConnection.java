package com.skillrisers.chatapp.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import static com.skillrisers.chatapp.utils.ConfigReader.getValue;
import static com.skillrisers.chatapp.utils.KeyConstants.*;
public interface DBConnection  {
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection connection = null;
		// Step-1 Loading a Driver
		Class.forName(getValue(DRIVER_NAME));
		// Step-2 Create a Connection
		Connection con = DriverManager.getConnection(getValue(DB_URL), 
				getValue(DB_USERID),
				getValue(DB_PWD));
		if(con!=null) {
			System.out.println("connection created...");
		}
		
		return connection;
	}

}
