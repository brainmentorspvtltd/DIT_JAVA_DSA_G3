package com.skillrisers.gaming;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.skillrisers.gaming.utils.GameConstants;

public class Board extends JPanel implements GameConstants {
	private BufferedImage backgroundImage ;
	
	public Board() throws IOException {
		loadBackgroundImage();
	}
	
	private void loadBackgroundImage() throws IOException {
		backgroundImage = ImageIO.read(Board.class.getResource("bg.jpeg"));
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(backgroundImage, 0,0,GWIDTH, GHEIGHT, null);
		
		
		
		
		// All Game Printing will be here
//		g.setColor(Color.RED);
//		g.fillRect(400, 500, 300, 300);
//		g.setColor(Color.GREEN);
//		g.fillOval(100, 100, 200, 200);
//		g.setColor(Color.BLACK);
//		Graphics2D g2 = (Graphics2D) g; // Downcasting
//		g2.setStroke(new BasicStroke(10));
//		g.drawLine(10,10,500,500);
//		g.drawOval(800,100,100,100);
	}

}
