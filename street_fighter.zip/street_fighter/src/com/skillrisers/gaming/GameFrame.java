package com.skillrisers.gaming;

import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.skillrisers.gaming.utils.GameConstants;

public class GameFrame extends JFrame implements GameConstants  {
	
	public GameFrame() throws IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle(TITLE);
		//setExtendedState(JFrame.MAXIMIZED_BOTH);
		setSize(GWIDTH, GHEIGHT);
		setLocationRelativeTo(null);
		Board board = new Board();
		add(board);
		setVisible(true);
	}

	public static void main(String[] args) {
		GameFrame obj = null;
		try {
			obj = new GameFrame();
		}
		catch(IOException ex) {
			JOptionPane.showMessageDialog(obj,"Something Went Wrong...");
			ex.printStackTrace();
			
		}
			

	}

}
