package com.skillrisers.gaming.utils;

public interface GameConstants {
	int GHEIGHT = 900; // public static final int GHEIGHT  =900
	int GWIDTH = 1500;
	String TITLE = "My Game - Street Fighter with SkillRisers";

}
