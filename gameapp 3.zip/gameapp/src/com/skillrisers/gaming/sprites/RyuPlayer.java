package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.skillrisers.gaming.utils.GameConstants;

public class RyuPlayer extends Player  {
	
	public RyuPlayer() throws IOException {
		x = 100;
		h = 200;
		w = 200;
		y = FLOOR - h;
		image = ImageIO.read(RyuPlayer.class.getResource(RYU_IMAGE));
	}
	@Override
	public BufferedImage defaultImage() {
		BufferedImage subImage = image.getSubimage(190,122,67,101);
		return subImage;
	}
	
	

}
