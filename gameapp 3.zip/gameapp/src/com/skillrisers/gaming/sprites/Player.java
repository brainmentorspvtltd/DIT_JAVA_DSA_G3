package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.skillrisers.gaming.utils.GameConstants;

public abstract class Player implements GameConstants {
	protected int x;
	protected int y;
	protected int w;
	protected int h;
	protected BufferedImage image;
	public abstract BufferedImage defaultImage();
	public void printPlayer(Graphics pen) {
		pen.drawImage(defaultImage(),x,y,w,h, null);
	}
}
