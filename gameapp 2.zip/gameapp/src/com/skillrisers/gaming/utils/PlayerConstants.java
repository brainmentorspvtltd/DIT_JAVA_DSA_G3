package com.skillrisers.gaming.utils;

public interface PlayerConstants {
	
	int STANDING = 1;
	int WALK = 2;
	int PUNCH = 3;
	int KICK = 4;
	int DAMAGE = 5;

}
