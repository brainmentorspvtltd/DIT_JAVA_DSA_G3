package com.brainmentors.bookingsystem.users.services;

import com.brainmentors.bookingsystem.users.dto.UserDTO;

public class UserService {
	
	// Contains the logic for Authentication
	public UserDTO auth(UserDTO user) {
		return null;
	}

}
