package com.brainmentors.bookingsystem.users.repository;

import com.brainmentors.bookingsystem.users.dto.UserDTO;

public class UserRepository {
	
	public UserDTO[] getAllUsers(){
		// Get 5 Users from the Memory
		return null;
	}

}
