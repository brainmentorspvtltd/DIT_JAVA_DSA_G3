package com.brainmentors.bookingsystem.users.views; // 1st line
// Login Screen / Console IO
public class LoginView {
	public void input() {
		// Take Input for Userid and Password
	}

}
